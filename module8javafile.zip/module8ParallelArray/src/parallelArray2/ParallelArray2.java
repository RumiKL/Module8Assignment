package parallelArray2;

import java.util.Random;

public class ParallelArray2 {
	private static int count = 0;
	
	public static synchronized void inccount() {
		count++;
	}

	public static void main(String[] args) {
		
		Thread t1 = new Thread (new Runnable() {

			public void run() {
				for(int i = 0; i <=200000; i++)
				inccount();
				Random r = new Random();
				int size = 10;
				
				int[] num1 = new int[size];
				int[] num2 = new int[size];
				int[] sumOfTwoNum = new int[size];
				
				for (int i = 0; i< size; i++) {
					num1[i] = r.nextInt(10) +1;
					num2[i] = r.nextInt(10) +1;
					sumOfTwoNum[i] = num1[i] + num2[i];
					System.out.println("Result:" +i+  ";num1="+num1[i]+ "; num2="+num2[i]+ "; sum="+sumOfTwoNum[i]);
			}
			}
		});	
		
		
		
		Thread t2 = new Thread (new Runnable() {

			public void run() {
				for(int i = 0; i <=200000; i++)
				inccount();
				Random r = new Random();
				int size = 10;
				
				int[] num1 = new int[size];
				int[] num2 = new int[size];
				int[] sumOfTwoNum = new int[size];
				
				for (int i = 0; i< size; i++) {
					num1[i] = r.nextInt(10) +1;
					num2[i] = r.nextInt(10) +1;
					sumOfTwoNum[i] = num1[i] + num2[i];
					System.out.println("Result:" +i+  ";num1="+num1[i]+ "; num2="+num2[i]+ "; sum="+sumOfTwoNum[i]);
				
				}
			}
			
		});	
				
		t1.start();
		t2.start();
		
		try {
			t1.join();
			t2.join();
		} catch (InterruptedException e) {
			
			e.printStackTrace();
		}
		
		System.out.print("value : " + count);
						
	}	
		}
		

	


