package parallelArray;

import java.util.Random;

public class ParallelArray {

	public static void main(String[] args) {
		Random r = new Random();
		int size = 10;
		
		int[] num1 = new int[size];
		int[] num2 = new int[size];
		int[] sumOfTwoNum = new int[size];
		
		for (int i = 0; i< size; i++) {
			num1[i] = r.nextInt(10) +1;
			num2[i] = r.nextInt(10) +1;
			sumOfTwoNum[i] = num1[i] + num2[i];
			System.out.println("Result:" +i+  ";num1="+num1[i]+ "; num2="+num2[i]+ "; sum="+sumOfTwoNum[i]);
			
		}
		

	}

}
